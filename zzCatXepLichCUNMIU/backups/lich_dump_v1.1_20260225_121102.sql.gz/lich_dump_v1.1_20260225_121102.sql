--
-- PostgreSQL database dump
--

\restrict XRjrqOdVhjfXnmtfulEf4GuzEYf7gptc8gc8HWPby0vE2vBYuyZhiCyPV2r08VU

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.nhu_cau_ca DROP CONSTRAINT IF EXISTS nhu_cau_ca_vai_tro_yeu_cau_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nhu_cau_ca DROP CONSTRAINT IF EXISTS nhu_cau_ca_chi_nhanh_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nhu_cau_ca DROP CONSTRAINT IF EXISTS nhu_cau_ca_ca_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_vai_tro DROP CONSTRAINT IF EXISTS nhan_vien_vai_tro_vai_tro_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_vai_tro DROP CONSTRAINT IF EXISTS nhan_vien_vai_tro_nhan_vien_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_trong_so DROP CONSTRAINT IF EXISTS nhan_vien_trong_so_trong_so_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_trong_so DROP CONSTRAINT IF EXISTS nhan_vien_trong_so_nhan_vien_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_chi_nhanh DROP CONSTRAINT IF EXISTS nhan_vien_chi_nhanh_nhan_vien_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_chi_nhanh DROP CONSTRAINT IF EXISTS nhan_vien_chi_nhanh_chi_nhanh_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_ca_ua_thich DROP CONSTRAINT IF EXISTS nhan_vien_ca_ua_thich_nhan_vien_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_ca_ua_thich DROP CONSTRAINT IF EXISTS nhan_vien_ca_ua_thich_ca_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_ca_tranh DROP CONSTRAINT IF EXISTS nhan_vien_ca_tranh_nhan_vien_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_ca_tranh DROP CONSTRAINT IF EXISTS nhan_vien_ca_tranh_ca_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ngay_nghi DROP CONSTRAINT IF EXISTS ngay_nghi_nhan_vien_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mapping_nhom DROP CONSTRAINT IF EXISTS mapping_nhom_nhom_hien_thi_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mapping_nhom DROP CONSTRAINT IF EXISTS mapping_nhom_chi_nhanh_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mapping_nhom DROP CONSTRAINT IF EXISTS mapping_nhom_ca_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lich_chi_tiet DROP CONSTRAINT IF EXISTS lich_chi_tiet_nhom_hien_thi_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lich_chi_tiet DROP CONSTRAINT IF EXISTS lich_chi_tiet_nhan_vien_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lich_chi_tiet DROP CONSTRAINT IF EXISTS lich_chi_tiet_lich_tuan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lich_chi_tiet DROP CONSTRAINT IF EXISTS lich_chi_tiet_chi_nhanh_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lich_chi_tiet DROP CONSTRAINT IF EXISTS lich_chi_tiet_ca_id_fkey;
DROP INDEX IF EXISTS public.ix_vai_tro_id;
DROP INDEX IF EXISTS public.ix_trong_so_uu_tien_id;
DROP INDEX IF EXISTS public.ix_nhu_cau_ca_id;
DROP INDEX IF EXISTS public.ix_nhom_hien_thi_id;
DROP INDEX IF EXISTS public.ix_nhan_vien_trong_so_id;
DROP INDEX IF EXISTS public.ix_nhan_vien_id;
DROP INDEX IF EXISTS public.ix_ngay_nghi_id;
DROP INDEX IF EXISTS public.ix_mapping_nhom_id;
DROP INDEX IF EXISTS public.ix_lich_tuan_id;
DROP INDEX IF EXISTS public.ix_lich_chi_tiet_id;
DROP INDEX IF EXISTS public.ix_chi_nhanh_id;
DROP INDEX IF EXISTS public.ix_ca_lam_id;
ALTER TABLE IF EXISTS ONLY public.vai_tro DROP CONSTRAINT IF EXISTS vai_tro_ten_vai_tro_key;
ALTER TABLE IF EXISTS ONLY public.vai_tro DROP CONSTRAINT IF EXISTS vai_tro_pkey;
ALTER TABLE IF EXISTS ONLY public.trong_so_uu_tien DROP CONSTRAINT IF EXISTS trong_so_uu_tien_pkey;
ALTER TABLE IF EXISTS ONLY public.trong_so_uu_tien DROP CONSTRAINT IF EXISTS trong_so_uu_tien_khoa_key;
ALTER TABLE IF EXISTS ONLY public.nhu_cau_ca DROP CONSTRAINT IF EXISTS nhu_cau_ca_pkey;
ALTER TABLE IF EXISTS ONLY public.nhom_hien_thi DROP CONSTRAINT IF EXISTS nhom_hien_thi_ten_nhom_key;
ALTER TABLE IF EXISTS ONLY public.nhom_hien_thi DROP CONSTRAINT IF EXISTS nhom_hien_thi_pkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_vai_tro DROP CONSTRAINT IF EXISTS nhan_vien_vai_tro_pkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_trong_so DROP CONSTRAINT IF EXISTS nhan_vien_trong_so_pkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien DROP CONSTRAINT IF EXISTS nhan_vien_pkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien DROP CONSTRAINT IF EXISTS nhan_vien_ma_nv_key;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_chi_nhanh DROP CONSTRAINT IF EXISTS nhan_vien_chi_nhanh_pkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_ca_ua_thich DROP CONSTRAINT IF EXISTS nhan_vien_ca_ua_thich_pkey;
ALTER TABLE IF EXISTS ONLY public.nhan_vien_ca_tranh DROP CONSTRAINT IF EXISTS nhan_vien_ca_tranh_pkey;
ALTER TABLE IF EXISTS ONLY public.ngay_nghi DROP CONSTRAINT IF EXISTS ngay_nghi_pkey;
ALTER TABLE IF EXISTS ONLY public.mapping_nhom DROP CONSTRAINT IF EXISTS mapping_nhom_pkey;
ALTER TABLE IF EXISTS ONLY public.lich_tuan DROP CONSTRAINT IF EXISTS lich_tuan_pkey;
ALTER TABLE IF EXISTS ONLY public.lich_chi_tiet DROP CONSTRAINT IF EXISTS lich_chi_tiet_pkey;
ALTER TABLE IF EXISTS ONLY public.chi_nhanh DROP CONSTRAINT IF EXISTS chi_nhanh_pkey;
ALTER TABLE IF EXISTS ONLY public.chi_nhanh DROP CONSTRAINT IF EXISTS chi_nhanh_ma_chi_nhanh_key;
ALTER TABLE IF EXISTS ONLY public.ca_lam DROP CONSTRAINT IF EXISTS ca_lam_ten_ca_key;
ALTER TABLE IF EXISTS ONLY public.ca_lam DROP CONSTRAINT IF EXISTS ca_lam_pkey;
ALTER TABLE IF EXISTS public.vai_tro ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.trong_so_uu_tien ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.nhu_cau_ca ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.nhom_hien_thi ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.nhan_vien_trong_so ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.nhan_vien ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ngay_nghi ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.mapping_nhom ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lich_tuan ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lich_chi_tiet ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.chi_nhanh ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ca_lam ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.vai_tro_id_seq;
DROP TABLE IF EXISTS public.vai_tro;
DROP SEQUENCE IF EXISTS public.trong_so_uu_tien_id_seq;
DROP TABLE IF EXISTS public.trong_so_uu_tien;
DROP SEQUENCE IF EXISTS public.nhu_cau_ca_id_seq;
DROP TABLE IF EXISTS public.nhu_cau_ca;
DROP SEQUENCE IF EXISTS public.nhom_hien_thi_id_seq;
DROP TABLE IF EXISTS public.nhom_hien_thi;
DROP TABLE IF EXISTS public.nhan_vien_vai_tro;
DROP SEQUENCE IF EXISTS public.nhan_vien_trong_so_id_seq;
DROP TABLE IF EXISTS public.nhan_vien_trong_so;
DROP SEQUENCE IF EXISTS public.nhan_vien_id_seq;
DROP TABLE IF EXISTS public.nhan_vien_chi_nhanh;
DROP TABLE IF EXISTS public.nhan_vien_ca_ua_thich;
DROP TABLE IF EXISTS public.nhan_vien_ca_tranh;
DROP TABLE IF EXISTS public.nhan_vien;
DROP SEQUENCE IF EXISTS public.ngay_nghi_id_seq;
DROP TABLE IF EXISTS public.ngay_nghi;
DROP SEQUENCE IF EXISTS public.mapping_nhom_id_seq;
DROP TABLE IF EXISTS public.mapping_nhom;
DROP SEQUENCE IF EXISTS public.lich_tuan_id_seq;
DROP TABLE IF EXISTS public.lich_tuan;
DROP SEQUENCE IF EXISTS public.lich_chi_tiet_id_seq;
DROP TABLE IF EXISTS public.lich_chi_tiet;
DROP SEQUENCE IF EXISTS public.chi_nhanh_id_seq;
DROP TABLE IF EXISTS public.chi_nhanh;
DROP SEQUENCE IF EXISTS public.ca_lam_id_seq;
DROP TABLE IF EXISTS public.ca_lam;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ca_lam; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.ca_lam (
    id integer NOT NULL,
    ten_ca character varying NOT NULL,
    gio_bat_dau character varying NOT NULL,
    gio_ket_thuc character varying NOT NULL,
    so_gio integer,
    la_ca_muon boolean
);


ALTER TABLE public.ca_lam OWNER TO lich_user;

--
-- Name: ca_lam_id_seq; Type: SEQUENCE; Schema: public; Owner: lich_user
--

CREATE SEQUENCE public.ca_lam_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ca_lam_id_seq OWNER TO lich_user;

--
-- Name: ca_lam_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lich_user
--

ALTER SEQUENCE public.ca_lam_id_seq OWNED BY public.ca_lam.id;


--
-- Name: chi_nhanh; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.chi_nhanh (
    id integer NOT NULL,
    ma_chi_nhanh character varying NOT NULL,
    ten_chi_nhanh character varying NOT NULL
);


ALTER TABLE public.chi_nhanh OWNER TO lich_user;

--
-- Name: chi_nhanh_id_seq; Type: SEQUENCE; Schema: public; Owner: lich_user
--

CREATE SEQUENCE public.chi_nhanh_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chi_nhanh_id_seq OWNER TO lich_user;

--
-- Name: chi_nhanh_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lich_user
--

ALTER SEQUENCE public.chi_nhanh_id_seq OWNED BY public.chi_nhanh.id;


--
-- Name: lich_chi_tiet; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.lich_chi_tiet (
    id integer NOT NULL,
    lich_tuan_id integer,
    ngay date NOT NULL,
    chi_nhanh_id integer,
    ca_id integer,
    nhan_vien_id integer,
    nhom_hien_thi_id integer,
    thu_tu integer DEFAULT 0
);


ALTER TABLE public.lich_chi_tiet OWNER TO lich_user;

--
-- Name: lich_chi_tiet_id_seq; Type: SEQUENCE; Schema: public; Owner: lich_user
--

CREATE SEQUENCE public.lich_chi_tiet_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lich_chi_tiet_id_seq OWNER TO lich_user;

--
-- Name: lich_chi_tiet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lich_user
--

ALTER SEQUENCE public.lich_chi_tiet_id_seq OWNED BY public.lich_chi_tiet.id;


--
-- Name: lich_tuan; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.lich_tuan (
    id integer NOT NULL,
    ngay_bat_dau date NOT NULL,
    ngay_ket_thuc date NOT NULL,
    trang_thai character varying,
    ghi_chu text,
    ten_lich character varying,
    spa_off_ghi_chu text
);


ALTER TABLE public.lich_tuan OWNER TO lich_user;

--
-- Name: lich_tuan_id_seq; Type: SEQUENCE; Schema: public; Owner: lich_user
--

CREATE SEQUENCE public.lich_tuan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lich_tuan_id_seq OWNER TO lich_user;

--
-- Name: lich_tuan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lich_user
--

ALTER SEQUENCE public.lich_tuan_id_seq OWNED BY public.lich_tuan.id;


--
-- Name: mapping_nhom; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.mapping_nhom (
    id integer NOT NULL,
    chi_nhanh_id integer,
    ca_id integer,
    nhom_hien_thi_id integer
);


ALTER TABLE public.mapping_nhom OWNER TO lich_user;

--
-- Name: mapping_nhom_id_seq; Type: SEQUENCE; Schema: public; Owner: lich_user
--

CREATE SEQUENCE public.mapping_nhom_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mapping_nhom_id_seq OWNER TO lich_user;

--
-- Name: mapping_nhom_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lich_user
--

ALTER SEQUENCE public.mapping_nhom_id_seq OWNED BY public.mapping_nhom.id;


--
-- Name: ngay_nghi; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.ngay_nghi (
    id integer NOT NULL,
    nhan_vien_id integer,
    ngay date NOT NULL,
    trang_thai character varying,
    ghi_chu text,
    nguon character varying DEFAULT 'user'::character varying
);


ALTER TABLE public.ngay_nghi OWNER TO lich_user;

--
-- Name: ngay_nghi_id_seq; Type: SEQUENCE; Schema: public; Owner: lich_user
--

CREATE SEQUENCE public.ngay_nghi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ngay_nghi_id_seq OWNER TO lich_user;

--
-- Name: ngay_nghi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lich_user
--

ALTER SEQUENCE public.ngay_nghi_id_seq OWNED BY public.ngay_nghi.id;


--
-- Name: nhan_vien; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.nhan_vien (
    id integer NOT NULL,
    ma_nv character varying NOT NULL,
    ten_nv character varying NOT NULL,
    cap_do character varying,
    muc_uu_tien integer,
    gio_toi_da_tuan integer,
    ghi_chu text
);


ALTER TABLE public.nhan_vien OWNER TO lich_user;

--
-- Name: nhan_vien_ca_tranh; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.nhan_vien_ca_tranh (
    nhan_vien_id integer NOT NULL,
    ca_id integer NOT NULL
);


ALTER TABLE public.nhan_vien_ca_tranh OWNER TO lich_user;

--
-- Name: nhan_vien_ca_ua_thich; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.nhan_vien_ca_ua_thich (
    nhan_vien_id integer NOT NULL,
    ca_id integer NOT NULL
);


ALTER TABLE public.nhan_vien_ca_ua_thich OWNER TO lich_user;

--
-- Name: nhan_vien_chi_nhanh; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.nhan_vien_chi_nhanh (
    nhan_vien_id integer NOT NULL,
    chi_nhanh_id integer NOT NULL
);


ALTER TABLE public.nhan_vien_chi_nhanh OWNER TO lich_user;

--
-- Name: nhan_vien_id_seq; Type: SEQUENCE; Schema: public; Owner: lich_user
--

CREATE SEQUENCE public.nhan_vien_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nhan_vien_id_seq OWNER TO lich_user;

--
-- Name: nhan_vien_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lich_user
--

ALTER SEQUENCE public.nhan_vien_id_seq OWNED BY public.nhan_vien.id;


--
-- Name: nhan_vien_trong_so; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.nhan_vien_trong_so (
    id integer NOT NULL,
    nhan_vien_id integer,
    trong_so_id integer,
    muc_uu_tien integer
);


ALTER TABLE public.nhan_vien_trong_so OWNER TO lich_user;

--
-- Name: nhan_vien_trong_so_id_seq; Type: SEQUENCE; Schema: public; Owner: lich_user
--

CREATE SEQUENCE public.nhan_vien_trong_so_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nhan_vien_trong_so_id_seq OWNER TO lich_user;

--
-- Name: nhan_vien_trong_so_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lich_user
--

ALTER SEQUENCE public.nhan_vien_trong_so_id_seq OWNED BY public.nhan_vien_trong_so.id;


--
-- Name: nhan_vien_vai_tro; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.nhan_vien_vai_tro (
    nhan_vien_id integer NOT NULL,
    vai_tro_id integer NOT NULL
);


ALTER TABLE public.nhan_vien_vai_tro OWNER TO lich_user;

--
-- Name: nhom_hien_thi; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.nhom_hien_thi (
    id integer NOT NULL,
    ten_nhom character varying NOT NULL,
    mau_nen character varying
);


ALTER TABLE public.nhom_hien_thi OWNER TO lich_user;

--
-- Name: nhom_hien_thi_id_seq; Type: SEQUENCE; Schema: public; Owner: lich_user
--

CREATE SEQUENCE public.nhom_hien_thi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nhom_hien_thi_id_seq OWNER TO lich_user;

--
-- Name: nhom_hien_thi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lich_user
--

ALTER SEQUENCE public.nhom_hien_thi_id_seq OWNED BY public.nhom_hien_thi.id;


--
-- Name: nhu_cau_ca; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.nhu_cau_ca (
    id integer NOT NULL,
    ngay date NOT NULL,
    chi_nhanh_id integer,
    ca_id integer,
    so_nguoi_can integer NOT NULL,
    vai_tro_yeu_cau_id integer,
    do_quan_trong integer,
    senior_toi_thieu integer
);


ALTER TABLE public.nhu_cau_ca OWNER TO lich_user;

--
-- Name: nhu_cau_ca_id_seq; Type: SEQUENCE; Schema: public; Owner: lich_user
--

CREATE SEQUENCE public.nhu_cau_ca_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nhu_cau_ca_id_seq OWNER TO lich_user;

--
-- Name: nhu_cau_ca_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lich_user
--

ALTER SEQUENCE public.nhu_cau_ca_id_seq OWNED BY public.nhu_cau_ca.id;


--
-- Name: trong_so_uu_tien; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.trong_so_uu_tien (
    id integer NOT NULL,
    khoa character varying NOT NULL,
    gia_tri integer
);


ALTER TABLE public.trong_so_uu_tien OWNER TO lich_user;

--
-- Name: trong_so_uu_tien_id_seq; Type: SEQUENCE; Schema: public; Owner: lich_user
--

CREATE SEQUENCE public.trong_so_uu_tien_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trong_so_uu_tien_id_seq OWNER TO lich_user;

--
-- Name: trong_so_uu_tien_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lich_user
--

ALTER SEQUENCE public.trong_so_uu_tien_id_seq OWNED BY public.trong_so_uu_tien.id;


--
-- Name: vai_tro; Type: TABLE; Schema: public; Owner: lich_user
--

CREATE TABLE public.vai_tro (
    id integer NOT NULL,
    ten_vai_tro character varying NOT NULL
);


ALTER TABLE public.vai_tro OWNER TO lich_user;

--
-- Name: vai_tro_id_seq; Type: SEQUENCE; Schema: public; Owner: lich_user
--

CREATE SEQUENCE public.vai_tro_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vai_tro_id_seq OWNER TO lich_user;

--
-- Name: vai_tro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lich_user
--

ALTER SEQUENCE public.vai_tro_id_seq OWNED BY public.vai_tro.id;


--
-- Name: ca_lam id; Type: DEFAULT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.ca_lam ALTER COLUMN id SET DEFAULT nextval('public.ca_lam_id_seq'::regclass);


--
-- Name: chi_nhanh id; Type: DEFAULT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.chi_nhanh ALTER COLUMN id SET DEFAULT nextval('public.chi_nhanh_id_seq'::regclass);


--
-- Name: lich_chi_tiet id; Type: DEFAULT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.lich_chi_tiet ALTER COLUMN id SET DEFAULT nextval('public.lich_chi_tiet_id_seq'::regclass);


--
-- Name: lich_tuan id; Type: DEFAULT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.lich_tuan ALTER COLUMN id SET DEFAULT nextval('public.lich_tuan_id_seq'::regclass);


--
-- Name: mapping_nhom id; Type: DEFAULT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.mapping_nhom ALTER COLUMN id SET DEFAULT nextval('public.mapping_nhom_id_seq'::regclass);


--
-- Name: ngay_nghi id; Type: DEFAULT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.ngay_nghi ALTER COLUMN id SET DEFAULT nextval('public.ngay_nghi_id_seq'::regclass);


--
-- Name: nhan_vien id; Type: DEFAULT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien ALTER COLUMN id SET DEFAULT nextval('public.nhan_vien_id_seq'::regclass);


--
-- Name: nhan_vien_trong_so id; Type: DEFAULT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_trong_so ALTER COLUMN id SET DEFAULT nextval('public.nhan_vien_trong_so_id_seq'::regclass);


--
-- Name: nhom_hien_thi id; Type: DEFAULT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhom_hien_thi ALTER COLUMN id SET DEFAULT nextval('public.nhom_hien_thi_id_seq'::regclass);


--
-- Name: nhu_cau_ca id; Type: DEFAULT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhu_cau_ca ALTER COLUMN id SET DEFAULT nextval('public.nhu_cau_ca_id_seq'::regclass);


--
-- Name: trong_so_uu_tien id; Type: DEFAULT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.trong_so_uu_tien ALTER COLUMN id SET DEFAULT nextval('public.trong_so_uu_tien_id_seq'::regclass);


--
-- Name: vai_tro id; Type: DEFAULT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.vai_tro ALTER COLUMN id SET DEFAULT nextval('public.vai_tro_id_seq'::regclass);


--
-- Data for Name: ca_lam; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.ca_lam (id, ten_ca, gio_bat_dau, gio_ket_thuc, so_gio, la_ca_muon) FROM stdin;
1	8h-19h	8h	19h	11	f
2	8h30-19h30	8h30	19h30	11	f
3	9h-20h	9h	20h	11	t
4	10h-21h	10h	21h	11	t
5	8h30-19h	8h30	19h	10	f
\.


--
-- Data for Name: chi_nhanh; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.chi_nhanh (id, ma_chi_nhanh, ten_chi_nhanh) FROM stdin;
1	326	326TTV
2	197	197LT5
3	796	796ADV
\.


--
-- Data for Name: lich_chi_tiet; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.lich_chi_tiet (id, lich_tuan_id, ngay, chi_nhanh_id, ca_id, nhan_vien_id, nhom_hien_thi_id, thu_tu) FROM stdin;
3235	43	2026-03-09	\N	3	11	4	1
3236	43	2026-03-09	2	1	8	2	1
3237	43	2026-03-09	\N	\N	7	6	1
3238	43	2026-03-09	1	4	9	1	7
3239	43	2026-03-09	\N	\N	3	5	2
3240	43	2026-03-09	1	3	1	1	5
3241	43	2026-03-09	\N	\N	6	5	1
3242	43	2026-03-09	2	3	2	2	3
3243	43	2026-03-09	1	1	10	1	1
3244	43	2026-03-09	1	2	5	1	3
3245	43	2026-03-09	2	4	4	2	5
3246	43	2026-03-10	\N	3	11	4	1
3247	43	2026-03-10	2	3	8	2	3
3248	43	2026-03-10	\N	\N	7	6	1
3249	43	2026-03-10	1	2	9	1	3
3250	43	2026-03-10	2	1	3	2	1
3251	43	2026-03-10	1	3	1	1	5
3252	43	2026-03-10	1	4	6	1	7
3253	43	2026-03-10	\N	\N	2	5	1
3254	43	2026-03-10	1	1	10	1	1
3255	43	2026-03-10	\N	\N	5	5	2
3256	43	2026-03-10	2	4	4	2	5
3257	43	2026-03-11	\N	3	11	4	1
3258	43	2026-03-11	2	3	8	2	3
3259	43	2026-03-11	\N	\N	7	6	1
3260	43	2026-03-11	1	1	9	1	1
3261	43	2026-03-11	2	1	3	2	1
3262	43	2026-03-11	1	3	1	1	5
3263	43	2026-03-11	1	4	6	1	7
3264	43	2026-03-11	\N	\N	2	5	2
3265	43	2026-03-11	\N	\N	10	5	1
3266	43	2026-03-11	1	2	5	1	3
3267	43	2026-03-11	2	4	4	2	5
3268	43	2026-03-12	\N	3	11	4	1
3269	43	2026-03-12	1	3	8	1	5
3270	43	2026-03-12	\N	\N	7	6	1
3271	43	2026-03-12	\N	\N	9	5	2
3272	43	2026-03-12	2	1	3	2	1
3273	43	2026-03-12	\N	\N	1	5	1
3274	43	2026-03-12	1	4	6	1	7
3275	43	2026-03-12	2	4	2	2	5
3276	43	2026-03-12	1	1	10	1	1
3277	43	2026-03-12	1	2	5	1	3
3278	43	2026-03-12	2	3	4	2	3
3279	43	2026-03-13	\N	\N	11	5	2
3280	43	2026-03-13	2	3	8	2	3
3281	43	2026-03-13	\N	\N	7	5	1
3282	43	2026-03-13	1	1	9	1	1
3283	43	2026-03-13	2	1	3	2	1
3284	43	2026-03-13	1	3	1	1	5
3285	43	2026-03-13	1	4	6	1	7
3286	43	2026-03-13	2	4	2	2	5
3287	43	2026-03-13	\N	\N	10	6	1
3288	43	2026-03-13	1	2	5	1	3
3289	43	2026-03-13	\N	3	4	4	1
3290	43	2026-03-14	\N	\N	11	5	1
3291	43	2026-03-14	\N	\N	8	5	2
3292	43	2026-03-14	\N	\N	7	6	1
3293	43	2026-03-14	1	1	9	1	1
3294	43	2026-03-14	2	1	3	2	1
3295	43	2026-03-14	1	3	1	1	5
3296	43	2026-03-14	1	4	6	1	7
3297	43	2026-03-14	2	4	2	2	5
3298	43	2026-03-14	2	3	10	2	3
3299	43	2026-03-14	1	2	5	1	3
3300	43	2026-03-14	\N	3	4	4	1
3301	43	2026-03-15	\N	\N	11	5	1
3302	43	2026-03-15	\N	\N	8	5	2
3303	43	2026-03-15	\N	\N	7	6	1
3304	43	2026-03-15	1	1	9	1	1
3306	43	2026-03-15	1	3	1	1	5
3305	43	2026-03-15	2	3	3	2	3
3307	43	2026-03-15	1	4	6	1	7
3308	43	2026-03-15	2	4	2	2	5
3310	43	2026-03-15	1	2	5	1	3
3311	43	2026-03-15	\N	3	4	4	1
3309	43	2026-03-15	2	1	10	2	1
3081	41	2026-02-09	\N	\N	11	7	1
3082	41	2026-02-09	\N	\N	8	7	2
3083	41	2026-02-09	\N	\N	7	7	3
3084	41	2026-02-09	\N	\N	9	7	4
3085	41	2026-02-09	\N	\N	3	5	1
3086	41	2026-02-09	\N	\N	1	7	5
3087	41	2026-02-09	\N	\N	6	7	6
3088	41	2026-02-09	\N	\N	2	7	7
3089	41	2026-02-09	\N	\N	10	7	8
3090	41	2026-02-09	\N	\N	5	7	9
3091	41	2026-02-09	\N	\N	4	7	10
3092	41	2026-02-10	\N	\N	11	7	1
3093	41	2026-02-10	\N	\N	8	7	2
3094	41	2026-02-10	\N	\N	7	7	3
3095	41	2026-02-10	\N	\N	9	7	4
3096	41	2026-02-10	\N	\N	3	7	5
3097	41	2026-02-10	\N	\N	1	7	6
3098	41	2026-02-10	\N	\N	6	7	7
3099	41	2026-02-10	\N	\N	2	7	8
3100	41	2026-02-10	\N	\N	10	7	9
3101	41	2026-02-10	\N	\N	5	7	10
3102	41	2026-02-10	\N	\N	4	7	11
3103	41	2026-02-11	\N	\N	11	7	1
3104	41	2026-02-11	\N	\N	8	7	2
3105	41	2026-02-11	\N	\N	7	7	3
3106	41	2026-02-11	\N	\N	9	7	4
3107	41	2026-02-11	\N	\N	3	7	5
3108	41	2026-02-11	\N	\N	1	7	6
3109	41	2026-02-11	\N	\N	6	7	7
3110	41	2026-02-11	\N	\N	2	7	8
3111	41	2026-02-11	\N	\N	10	7	9
3112	41	2026-02-11	\N	\N	5	7	10
3113	41	2026-02-11	\N	\N	4	7	11
3114	41	2026-02-12	\N	\N	11	7	1
3115	41	2026-02-12	\N	\N	8	7	2
3116	41	2026-02-12	\N	\N	7	7	3
3117	41	2026-02-12	\N	\N	9	7	4
3118	41	2026-02-12	\N	\N	3	7	5
3119	41	2026-02-12	\N	\N	1	7	6
3120	41	2026-02-12	\N	\N	6	7	7
3121	41	2026-02-12	\N	\N	2	7	8
3122	41	2026-02-12	\N	\N	10	7	9
3123	41	2026-02-12	\N	\N	5	7	10
3124	41	2026-02-12	\N	\N	4	7	11
3125	41	2026-02-13	\N	\N	11	7	1
3126	41	2026-02-13	\N	\N	8	7	2
3127	41	2026-02-13	\N	\N	7	7	3
3128	41	2026-02-13	\N	\N	9	7	4
3129	41	2026-02-13	\N	\N	3	7	5
3130	41	2026-02-13	\N	\N	1	7	6
3131	41	2026-02-13	\N	\N	6	7	7
3132	41	2026-02-13	\N	\N	2	7	8
3133	41	2026-02-13	\N	\N	10	7	9
3134	41	2026-02-13	\N	\N	5	7	10
3135	41	2026-02-13	\N	\N	4	7	11
3136	41	2026-02-14	\N	\N	11	7	1
3137	41	2026-02-14	\N	\N	8	5	1
3138	41	2026-02-14	\N	\N	7	7	2
3139	41	2026-02-14	\N	\N	9	7	3
3140	41	2026-02-14	\N	\N	3	7	4
3141	41	2026-02-14	\N	\N	1	7	5
3142	41	2026-02-14	\N	\N	6	7	6
3143	41	2026-02-14	\N	\N	2	7	7
3144	41	2026-02-14	\N	\N	10	7	8
3145	41	2026-02-14	\N	\N	5	7	9
3146	41	2026-02-14	\N	\N	4	7	10
3147	41	2026-02-15	\N	\N	11	7	1
3148	41	2026-02-15	\N	\N	8	5	1
3149	41	2026-02-15	\N	\N	7	7	2
3150	41	2026-02-15	\N	\N	9	7	3
3151	41	2026-02-15	\N	\N	3	7	4
3152	41	2026-02-15	\N	\N	1	7	5
3153	41	2026-02-15	\N	\N	6	7	6
3154	41	2026-02-15	\N	\N	2	7	7
3155	41	2026-02-15	\N	\N	10	7	8
3156	41	2026-02-15	\N	\N	5	7	9
3157	41	2026-02-15	\N	\N	4	7	10
2467	33	2026-03-02	1	1	7	1	1
2469	33	2026-03-02	2	1	3	2	1
2468	33	2026-03-02	1	2	9	1	3
2471	33	2026-03-02	\N	\N	6	5	1
2470	33	2026-03-02	1	3	1	1	5
2472	33	2026-03-02	2	4	2	2	5
2474	33	2026-03-02	\N	\N	5	6	2
2473	33	2026-03-02	2	3	10	2	3
2478	33	2026-03-03	1	1	7	1	1
2475	33	2026-03-02	1	4	4	1	7
2480	33	2026-03-03	2	1	3	2	1
2479	33	2026-03-03	1	2	9	1	3
2481	33	2026-03-03	1	3	1	1	5
2482	33	2026-03-03	2	4	6	2	5
2485	33	2026-03-03	\N	\N	5	6	2
2484	33	2026-03-03	2	3	10	2	3
2486	33	2026-03-03	1	4	4	1	7
2491	33	2026-03-04	2	1	3	2	1
2490	33	2026-03-04	1	2	9	1	3
2492	33	2026-03-04	1	3	1	1	5
2493	33	2026-03-04	2	3	6	2	3
2495	33	2026-03-04	1	1	10	1	1
2494	33	2026-03-04	2	4	2	2	5
2500	33	2026-03-05	1	1	7	1	1
2497	33	2026-03-04	1	4	4	1	7
2501	33	2026-03-05	1	2	9	1	3
2504	33	2026-03-05	2	1	6	2	1
2503	33	2026-03-05	1	3	1	1	5
2523	33	2026-03-07	\N	\N	9	5	1
2505	33	2026-03-05	2	4	2	2	5
2507	33	2026-03-05	\N	\N	5	6	2
2506	33	2026-03-05	2	3	10	2	3
2511	33	2026-03-06	1	1	7	1	1
2508	33	2026-03-05	1	4	4	1	7
2512	33	2026-03-06	1	2	9	1	3
2514	33	2026-03-06	1	3	1	1	5
2515	33	2026-03-06	2	3	6	2	3
2465	33	2026-03-02	\N	3	11	4	1
2476	33	2026-03-03	\N	3	11	4	1
2534	33	2026-03-08	\N	\N	9	5	1
2535	33	2026-03-08	\N	\N	3	5	2
2487	33	2026-03-04	\N	3	11	4	1
2502	33	2026-03-05	\N	3	3	4	1
2513	33	2026-03-06	\N	3	3	4	1
2516	33	2026-03-06	2	4	2	2	5
2466	33	2026-03-02	\N	\N	8	6	1
2477	33	2026-03-03	\N	\N	8	6	1
2483	33	2026-03-03	\N	\N	2	5	1
2488	33	2026-03-04	\N	\N	8	6	1
2489	33	2026-03-04	\N	\N	7	5	2
2496	33	2026-03-04	\N	\N	5	5	1
2498	33	2026-03-05	\N	\N	11	5	1
2499	33	2026-03-05	\N	\N	8	6	1
2509	33	2026-03-06	\N	\N	11	5	1
2510	33	2026-03-06	\N	\N	8	6	1
2517	33	2026-03-06	\N	\N	10	5	2
2520	33	2026-03-07	\N	\N	11	5	2
2521	33	2026-03-07	\N	\N	8	6	1
2532	33	2026-03-08	\N	\N	8	6	1
2518	33	2026-03-06	2	1	5	2	1
2519	33	2026-03-06	1	4	4	1	7
2522	33	2026-03-07	1	1	7	1	1
2525	33	2026-03-07	1	3	1	1	5
2526	33	2026-03-07	2	1	6	2	1
2527	33	2026-03-07	2	3	2	2	3
2528	33	2026-03-07	1	2	10	1	3
2529	33	2026-03-07	2	4	5	2	5
2530	33	2026-03-07	1	4	4	1	7
2533	33	2026-03-08	1	1	7	1	1
2536	33	2026-03-08	1	3	1	1	5
2537	33	2026-03-08	2	1	6	2	1
2538	33	2026-03-08	2	4	2	2	5
2539	33	2026-03-08	1	2	10	1	3
2540	33	2026-03-08	2	3	5	2	3
2541	33	2026-03-08	1	4	4	1	7
2524	33	2026-03-07	\N	3	3	4	1
2531	33	2026-03-08	\N	3	11	4	1
\.


--
-- Data for Name: lich_tuan; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.lich_tuan (id, ngay_bat_dau, ngay_ket_thuc, trang_thai, ghi_chu, ten_lich, spa_off_ghi_chu) FROM stdin;
33	2026-03-02	2026-03-08	TU_XEP	Lịch đúng	Lịch Thơ Xếp Chính Thức	{"2026-03-03": "Test Test"}
41	2026-02-09	2026-02-15	TU_XEP	Tho xep dung	Tự xếp 09/02/2026	\N
43	2026-03-09	2026-03-15	TU_XEP	Lịch thơ xếp cho tuần 9/3 ->15/3	Thơ xếp cho tuần 9/3	\N
\.


--
-- Data for Name: mapping_nhom; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.mapping_nhom (id, chi_nhanh_id, ca_id, nhom_hien_thi_id) FROM stdin;
1	1	1	1
2	2	1	2
3	1	2	1
4	1	3	1
5	2	3	2
6	3	3	3
7	\N	3	4
8	1	4	1
9	2	4	2
\.


--
-- Data for Name: ngay_nghi; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.ngay_nghi (id, nhan_vien_id, ngay, trang_thai, ghi_chu, nguon) FROM stdin;
43	8	2026-02-14	OFF	\N	user
44	8	2026-02-15	OFF	\N	user
45	3	2026-02-09	OFF	\N	user
46	9	2026-02-16	OFF	\N	user
\.


--
-- Data for Name: nhan_vien; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.nhan_vien (id, ma_nv, ten_nv, cap_do, muc_uu_tien, gio_toi_da_tuan, ghi_chu) FROM stdin;
1	BS01	Hữu	Bác sỹ chính	5	66	\N
2	BS02	Nhựt	Bác sỹ chính	5	66	\N
3	BS03	Hồng	Bác sỹ chính	5	66	\N
4	BS04	Thy	Bác sỹ chính	5	66	\N
5	BS05	Thùy	Bác sỹ mới	2	66	\N
6	BS06	My	Bác sỹ mới	2	66	\N
7	BS07	Hà	Bác sỹ mới	2	66	\N
8	BS08	Đạt	Bác sỹ mới	2	66	\N
9	BS09	Hiếu	Bác sỹ mới	2	66	\N
10	BS10	Phong	Bác sỹ mới	2	66	\N
11	BS11	Đăng	Bác sỹ mới	2	66	\N
\.


--
-- Data for Name: nhan_vien_ca_tranh; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.nhan_vien_ca_tranh (nhan_vien_id, ca_id) FROM stdin;
4	2
4	1
4	3
1	2
1	1
2	2
2	1
8	1
8	4
9	1
9	4
1	5
1	4
5	4
5	3
5	5
\.


--
-- Data for Name: nhan_vien_ca_ua_thich; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.nhan_vien_ca_ua_thich (nhan_vien_id, ca_id) FROM stdin;
3	1
2	4
1	3
\.


--
-- Data for Name: nhan_vien_chi_nhanh; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.nhan_vien_chi_nhanh (nhan_vien_id, chi_nhanh_id) FROM stdin;
2	2
11	3
1	1
7	1
7	3
5	2
5	1
\.


--
-- Data for Name: nhan_vien_trong_so; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.nhan_vien_trong_so (id, nhan_vien_id, trong_so_id, muc_uu_tien) FROM stdin;
5	8	5	6
6	9	5	6
7	1	5	6
\.


--
-- Data for Name: nhan_vien_vai_tro; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.nhan_vien_vai_tro (nhan_vien_id, vai_tro_id) FROM stdin;
2	1
8	1
3	1
1	1
9	1
4	1
10	1
5	1
11	1
6	1
7	1
\.


--
-- Data for Name: nhom_hien_thi; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.nhom_hien_thi (id, ten_nhom, mau_nen) FROM stdin;
1	326TTV	#d7f2ff
2	197LT5	#d9f7e6
3	796ADV	#fff1c9
4	CN	#ffd8e6
5	OFF	#e6e6e6
6	PHU_SPA	#f2d7ff
7	CHUA_XEP	#f4f4f4
\.


--
-- Data for Name: nhu_cau_ca; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.nhu_cau_ca (id, ngay, chi_nhanh_id, ca_id, so_nguoi_can, vai_tro_yeu_cau_id, do_quan_trong, senior_toi_thieu) FROM stdin;
1	2026-02-16	1	1	1	\N	3	\N
2	2026-02-16	1	3	1	\N	4	\N
3	2026-02-16	2	3	1	\N	3	\N
4	2026-02-16	3	3	1	\N	2	\N
5	2026-02-17	1	1	1	\N	3	\N
6	2026-02-17	1	3	1	\N	4	\N
7	2026-02-17	2	3	1	\N	3	\N
8	2026-02-17	3	3	1	\N	2	\N
9	2026-02-18	1	1	1	\N	3	\N
10	2026-02-18	1	3	1	\N	4	\N
11	2026-02-18	2	3	1	\N	3	\N
12	2026-02-18	3	3	1	\N	2	\N
13	2026-02-19	1	1	1	\N	3	\N
14	2026-02-19	1	3	1	\N	4	\N
15	2026-02-19	2	3	1	\N	3	\N
16	2026-02-19	3	3	1	\N	2	\N
17	2026-02-20	1	1	1	\N	3	\N
18	2026-02-20	1	3	1	\N	4	\N
19	2026-02-20	2	3	1	\N	3	\N
20	2026-02-20	3	3	1	\N	2	\N
21	2026-02-21	1	1	1	\N	3	\N
22	2026-02-21	1	3	1	\N	4	\N
23	2026-02-21	2	3	1	\N	3	\N
24	2026-02-21	3	3	1	\N	2	\N
25	2026-02-22	1	1	1	\N	3	\N
26	2026-02-22	1	3	1	\N	4	\N
27	2026-02-22	2	3	1	\N	3	\N
28	2026-02-22	3	3	1	\N	2	\N
29	2026-02-16	1	2	1	\N	3	\N
30	2026-02-17	1	2	1	\N	3	\N
31	2026-02-18	1	2	1	\N	3	\N
32	2026-02-19	1	2	1	\N	3	\N
33	2026-02-20	1	2	1	\N	3	\N
34	2026-02-21	1	2	1	\N	3	\N
35	2026-02-22	1	2	1	\N	3	\N
36	2026-02-16	1	4	1	\N	3	\N
37	2026-02-17	1	4	1	\N	3	\N
38	2026-02-18	1	4	1	\N	3	\N
39	2026-02-19	1	4	1	\N	3	\N
40	2026-02-20	1	4	1	\N	3	\N
41	2026-02-21	1	4	1	\N	3	\N
42	2026-02-22	1	4	1	\N	3	\N
43	2026-02-16	2	1	1	\N	3	\N
44	2026-02-17	2	1	1	\N	3	\N
45	2026-02-18	2	1	1	\N	3	\N
46	2026-02-19	2	1	1	\N	3	\N
47	2026-02-20	2	1	1	\N	3	\N
48	2026-02-21	2	1	1	\N	3	\N
49	2026-02-22	2	1	1	\N	3	\N
50	2026-02-16	2	4	1	\N	3	\N
51	2026-02-17	2	4	1	\N	3	\N
52	2026-02-18	2	4	1	\N	3	\N
53	2026-02-19	2	4	1	\N	3	\N
54	2026-02-20	2	4	1	\N	3	\N
55	2026-02-21	2	4	1	\N	3	\N
56	2026-02-22	2	4	1	\N	3	\N
57	2026-03-02	1	1	1	\N	3	\N
58	2026-03-02	1	3	1	\N	4	\N
59	2026-03-02	2	3	1	\N	3	\N
60	2026-03-02	3	3	1	\N	2	\N
61	2026-03-03	1	1	1	\N	3	\N
62	2026-03-03	1	3	1	\N	4	\N
63	2026-03-03	2	3	1	\N	3	\N
64	2026-03-03	3	3	1	\N	2	\N
65	2026-03-04	1	1	1	\N	3	\N
66	2026-03-04	1	3	1	\N	4	\N
67	2026-03-04	2	3	1	\N	3	\N
68	2026-03-04	3	3	1	\N	2	\N
69	2026-03-05	1	1	1	\N	3	\N
70	2026-03-05	1	3	1	\N	4	\N
71	2026-03-05	2	3	1	\N	3	\N
72	2026-03-05	3	3	1	\N	2	\N
73	2026-03-06	1	1	1	\N	3	\N
74	2026-03-06	1	3	1	\N	4	\N
75	2026-03-06	2	3	1	\N	3	\N
76	2026-03-06	3	3	1	\N	2	\N
77	2026-03-07	1	1	1	\N	3	\N
78	2026-03-07	1	3	1	\N	4	\N
79	2026-03-07	2	3	1	\N	3	\N
80	2026-03-07	3	3	1	\N	2	\N
81	2026-03-08	1	1	1	\N	3	\N
82	2026-03-08	1	3	1	\N	4	\N
83	2026-03-08	2	3	1	\N	3	\N
84	2026-03-08	3	3	1	\N	2	\N
85	2026-03-02	1	2	1	\N	3	\N
86	2026-03-03	1	2	1	\N	3	\N
87	2026-03-04	1	2	1	\N	3	\N
88	2026-03-05	1	2	1	\N	3	\N
89	2026-03-06	1	2	1	\N	3	\N
90	2026-03-07	1	2	1	\N	3	\N
91	2026-03-08	1	2	1	\N	3	\N
92	2026-03-02	1	4	1	\N	3	\N
93	2026-03-03	1	4	1	\N	3	\N
94	2026-03-04	1	4	1	\N	3	\N
95	2026-03-05	1	4	1	\N	3	\N
96	2026-03-06	1	4	1	\N	3	\N
97	2026-03-07	1	4	1	\N	3	\N
98	2026-03-08	1	4	1	\N	3	\N
99	2026-03-02	2	1	1	\N	3	\N
100	2026-03-03	2	1	1	\N	3	\N
101	2026-03-04	2	1	1	\N	3	\N
102	2026-03-05	2	1	1	\N	3	\N
103	2026-03-06	2	1	1	\N	3	\N
104	2026-03-07	2	1	1	\N	3	\N
105	2026-03-08	2	1	1	\N	3	\N
106	2026-03-02	2	4	1	\N	3	\N
107	2026-03-03	2	4	1	\N	3	\N
108	2026-03-04	2	4	1	\N	3	\N
109	2026-03-05	2	4	1	\N	3	\N
110	2026-03-06	2	4	1	\N	3	\N
111	2026-03-07	2	4	1	\N	3	\N
112	2026-03-08	2	4	1	\N	3	\N
113	2026-02-23	1	1	1	\N	3	\N
114	2026-02-23	1	3	1	\N	4	\N
115	2026-02-23	2	3	1	\N	3	\N
116	2026-02-23	3	3	1	\N	2	\N
117	2026-02-24	1	1	1	\N	3	\N
118	2026-02-24	1	3	1	\N	4	\N
119	2026-02-24	2	3	1	\N	3	\N
120	2026-02-24	3	3	1	\N	2	\N
121	2026-02-25	1	1	1	\N	3	\N
122	2026-02-25	1	3	1	\N	4	\N
123	2026-02-25	2	3	1	\N	3	\N
124	2026-02-25	3	3	1	\N	2	\N
125	2026-02-26	1	1	1	\N	3	\N
126	2026-02-26	1	3	1	\N	4	\N
127	2026-02-26	2	3	1	\N	3	\N
128	2026-02-26	3	3	1	\N	2	\N
129	2026-02-27	1	1	1	\N	3	\N
130	2026-02-27	1	3	1	\N	4	\N
131	2026-02-27	2	3	1	\N	3	\N
132	2026-02-27	3	3	1	\N	2	\N
133	2026-02-28	1	1	1	\N	3	\N
134	2026-02-28	1	3	1	\N	4	\N
135	2026-02-28	2	3	1	\N	3	\N
136	2026-02-28	3	3	1	\N	2	\N
137	2026-03-01	1	1	1	\N	3	\N
138	2026-03-01	1	3	1	\N	4	\N
139	2026-03-01	2	3	1	\N	3	\N
140	2026-03-01	3	3	1	\N	2	\N
141	2026-02-23	1	2	1	\N	3	\N
142	2026-02-24	1	2	1	\N	3	\N
143	2026-02-25	1	2	1	\N	3	\N
144	2026-02-26	1	2	1	\N	3	\N
145	2026-02-27	1	2	1	\N	3	\N
146	2026-02-28	1	2	1	\N	3	\N
147	2026-03-01	1	2	1	\N	3	\N
148	2026-02-23	1	4	1	\N	3	\N
149	2026-02-24	1	4	1	\N	3	\N
150	2026-02-25	1	4	1	\N	3	\N
151	2026-02-26	1	4	1	\N	3	\N
152	2026-02-27	1	4	1	\N	3	\N
153	2026-02-28	1	4	1	\N	3	\N
154	2026-03-01	1	4	1	\N	3	\N
155	2026-02-23	2	1	1	\N	3	\N
156	2026-02-24	2	1	1	\N	3	\N
157	2026-02-25	2	1	1	\N	3	\N
158	2026-02-26	2	1	1	\N	3	\N
159	2026-02-27	2	1	1	\N	3	\N
160	2026-02-28	2	1	1	\N	3	\N
161	2026-03-01	2	1	1	\N	3	\N
162	2026-02-23	2	4	1	\N	3	\N
163	2026-02-24	2	4	1	\N	3	\N
164	2026-02-25	2	4	1	\N	3	\N
165	2026-02-26	2	4	1	\N	3	\N
166	2026-02-27	2	4	1	\N	3	\N
167	2026-02-28	2	4	1	\N	3	\N
168	2026-03-01	2	4	1	\N	3	\N
169	2026-03-09	1	1	1	\N	3	\N
170	2026-03-09	1	3	1	\N	4	\N
171	2026-03-09	2	3	1	\N	3	\N
172	2026-03-09	3	3	1	\N	2	\N
173	2026-03-10	1	1	1	\N	3	\N
174	2026-03-10	1	3	1	\N	4	\N
175	2026-03-10	2	3	1	\N	3	\N
176	2026-03-10	3	3	1	\N	2	\N
177	2026-03-11	1	1	1	\N	3	\N
178	2026-03-11	1	3	1	\N	4	\N
179	2026-03-11	2	3	1	\N	3	\N
180	2026-03-11	3	3	1	\N	2	\N
181	2026-03-12	1	1	1	\N	3	\N
182	2026-03-12	1	3	1	\N	4	\N
183	2026-03-12	2	3	1	\N	3	\N
184	2026-03-12	3	3	1	\N	2	\N
185	2026-03-13	1	1	1	\N	3	\N
186	2026-03-13	1	3	1	\N	4	\N
187	2026-03-13	2	3	1	\N	3	\N
188	2026-03-13	3	3	1	\N	2	\N
189	2026-03-14	1	1	1	\N	3	\N
190	2026-03-14	1	3	1	\N	4	\N
191	2026-03-14	2	3	1	\N	3	\N
192	2026-03-14	3	3	1	\N	2	\N
193	2026-03-15	1	1	1	\N	3	\N
194	2026-03-15	1	3	1	\N	4	\N
195	2026-03-15	2	3	1	\N	3	\N
196	2026-03-15	3	3	1	\N	2	\N
197	2026-03-09	1	2	1	\N	3	\N
198	2026-03-10	1	2	1	\N	3	\N
199	2026-03-11	1	2	1	\N	3	\N
200	2026-03-12	1	2	1	\N	3	\N
201	2026-03-13	1	2	1	\N	3	\N
202	2026-03-14	1	2	1	\N	3	\N
203	2026-03-15	1	2	1	\N	3	\N
204	2026-03-09	1	4	1	\N	3	\N
205	2026-03-10	1	4	1	\N	3	\N
206	2026-03-11	1	4	1	\N	3	\N
207	2026-03-12	1	4	1	\N	3	\N
208	2026-03-13	1	4	1	\N	3	\N
209	2026-03-14	1	4	1	\N	3	\N
210	2026-03-15	1	4	1	\N	3	\N
211	2026-03-09	2	1	1	\N	3	\N
212	2026-03-10	2	1	1	\N	3	\N
213	2026-03-11	2	1	1	\N	3	\N
214	2026-03-12	2	1	1	\N	3	\N
215	2026-03-13	2	1	1	\N	3	\N
216	2026-03-14	2	1	1	\N	3	\N
217	2026-03-15	2	1	1	\N	3	\N
218	2026-03-09	2	4	1	\N	3	\N
219	2026-03-10	2	4	1	\N	3	\N
220	2026-03-11	2	4	1	\N	3	\N
221	2026-03-12	2	4	1	\N	3	\N
222	2026-03-13	2	4	1	\N	3	\N
223	2026-03-14	2	4	1	\N	3	\N
224	2026-03-15	2	4	1	\N	3	\N
225	2026-03-23	1	1	1	\N	3	\N
226	2026-03-23	1	3	1	\N	4	\N
227	2026-03-23	2	3	1	\N	3	\N
228	2026-03-23	3	3	1	\N	2	\N
229	2026-03-24	1	1	1	\N	3	\N
230	2026-03-24	1	3	1	\N	4	\N
231	2026-03-24	2	3	1	\N	3	\N
232	2026-03-24	3	3	1	\N	2	\N
233	2026-03-25	1	1	1	\N	3	\N
234	2026-03-25	1	3	1	\N	4	\N
235	2026-03-25	2	3	1	\N	3	\N
236	2026-03-25	3	3	1	\N	2	\N
237	2026-03-26	1	1	1	\N	3	\N
238	2026-03-26	1	3	1	\N	4	\N
239	2026-03-26	2	3	1	\N	3	\N
240	2026-03-26	3	3	1	\N	2	\N
241	2026-03-27	1	1	1	\N	3	\N
242	2026-03-27	1	3	1	\N	4	\N
243	2026-03-27	2	3	1	\N	3	\N
244	2026-03-27	3	3	1	\N	2	\N
245	2026-03-28	1	1	1	\N	3	\N
246	2026-03-28	1	3	1	\N	4	\N
247	2026-03-28	2	3	1	\N	3	\N
248	2026-03-28	3	3	1	\N	2	\N
249	2026-03-29	1	1	1	\N	3	\N
250	2026-03-29	1	3	1	\N	4	\N
251	2026-03-29	2	3	1	\N	3	\N
252	2026-03-29	3	3	1	\N	2	\N
253	2026-03-23	1	2	1	\N	3	\N
254	2026-03-24	1	2	1	\N	3	\N
255	2026-03-25	1	2	1	\N	3	\N
256	2026-03-26	1	2	1	\N	3	\N
257	2026-03-27	1	2	1	\N	3	\N
258	2026-03-28	1	2	1	\N	3	\N
259	2026-03-29	1	2	1	\N	3	\N
260	2026-03-23	1	4	1	\N	3	\N
261	2026-03-24	1	4	1	\N	3	\N
262	2026-03-25	1	4	1	\N	3	\N
263	2026-03-26	1	4	1	\N	3	\N
264	2026-03-27	1	4	1	\N	3	\N
265	2026-03-28	1	4	1	\N	3	\N
266	2026-03-29	1	4	1	\N	3	\N
267	2026-03-23	2	1	1	\N	3	\N
268	2026-03-24	2	1	1	\N	3	\N
269	2026-03-25	2	1	1	\N	3	\N
270	2026-03-26	2	1	1	\N	3	\N
271	2026-03-27	2	1	1	\N	3	\N
272	2026-03-28	2	1	1	\N	3	\N
273	2026-03-29	2	1	1	\N	3	\N
274	2026-03-23	2	4	1	\N	3	\N
275	2026-03-24	2	4	1	\N	3	\N
276	2026-03-25	2	4	1	\N	3	\N
277	2026-03-26	2	4	1	\N	3	\N
278	2026-03-27	2	4	1	\N	3	\N
279	2026-03-28	2	4	1	\N	3	\N
280	2026-03-29	2	4	1	\N	3	\N
281	2026-03-30	1	1	1	\N	3	\N
282	2026-03-30	1	3	1	\N	4	\N
283	2026-03-30	2	3	1	\N	3	\N
284	2026-03-30	3	3	1	\N	2	\N
285	2026-03-31	1	1	1	\N	3	\N
286	2026-03-31	1	3	1	\N	4	\N
287	2026-03-31	2	3	1	\N	3	\N
288	2026-03-31	3	3	1	\N	2	\N
289	2026-04-01	1	1	1	\N	3	\N
290	2026-04-01	1	3	1	\N	4	\N
291	2026-04-01	2	3	1	\N	3	\N
292	2026-04-01	3	3	1	\N	2	\N
293	2026-04-02	1	1	1	\N	3	\N
294	2026-04-02	1	3	1	\N	4	\N
295	2026-04-02	2	3	1	\N	3	\N
296	2026-04-02	3	3	1	\N	2	\N
297	2026-04-03	1	1	1	\N	3	\N
298	2026-04-03	1	3	1	\N	4	\N
299	2026-04-03	2	3	1	\N	3	\N
300	2026-04-03	3	3	1	\N	2	\N
301	2026-04-04	1	1	1	\N	3	\N
302	2026-04-04	1	3	1	\N	4	\N
303	2026-04-04	2	3	1	\N	3	\N
304	2026-04-04	3	3	1	\N	2	\N
305	2026-04-05	1	1	1	\N	3	\N
306	2026-04-05	1	3	1	\N	4	\N
307	2026-04-05	2	3	1	\N	3	\N
308	2026-04-05	3	3	1	\N	2	\N
309	2026-03-30	1	2	1	\N	3	\N
310	2026-03-31	1	2	1	\N	3	\N
311	2026-04-01	1	2	1	\N	3	\N
312	2026-04-02	1	2	1	\N	3	\N
313	2026-04-03	1	2	1	\N	3	\N
314	2026-04-04	1	2	1	\N	3	\N
315	2026-04-05	1	2	1	\N	3	\N
316	2026-03-30	1	4	1	\N	3	\N
317	2026-03-31	1	4	1	\N	3	\N
318	2026-04-01	1	4	1	\N	3	\N
319	2026-04-02	1	4	1	\N	3	\N
320	2026-04-03	1	4	1	\N	3	\N
321	2026-04-04	1	4	1	\N	3	\N
322	2026-04-05	1	4	1	\N	3	\N
323	2026-03-30	2	1	1	\N	3	\N
324	2026-03-31	2	1	1	\N	3	\N
325	2026-04-01	2	1	1	\N	3	\N
326	2026-04-02	2	1	1	\N	3	\N
327	2026-04-03	2	1	1	\N	3	\N
328	2026-04-04	2	1	1	\N	3	\N
329	2026-04-05	2	1	1	\N	3	\N
330	2026-03-30	2	4	1	\N	3	\N
331	2026-03-31	2	4	1	\N	3	\N
332	2026-04-01	2	4	1	\N	3	\N
333	2026-04-02	2	4	1	\N	3	\N
334	2026-04-03	2	4	1	\N	3	\N
335	2026-04-04	2	4	1	\N	3	\N
336	2026-04-05	2	4	1	\N	3	\N
337	2026-04-13	1	1	1	\N	3	\N
338	2026-04-13	1	3	1	\N	4	\N
339	2026-04-13	2	3	1	\N	3	\N
340	2026-04-13	3	3	1	\N	2	\N
341	2026-04-14	1	1	1	\N	3	\N
342	2026-04-14	1	3	1	\N	4	\N
343	2026-04-14	2	3	1	\N	3	\N
344	2026-04-14	3	3	1	\N	2	\N
345	2026-04-15	1	1	1	\N	3	\N
346	2026-04-15	1	3	1	\N	4	\N
347	2026-04-15	2	3	1	\N	3	\N
348	2026-04-15	3	3	1	\N	2	\N
349	2026-04-16	1	1	1	\N	3	\N
350	2026-04-16	1	3	1	\N	4	\N
351	2026-04-16	2	3	1	\N	3	\N
352	2026-04-16	3	3	1	\N	2	\N
353	2026-04-17	1	1	1	\N	3	\N
354	2026-04-17	1	3	1	\N	4	\N
355	2026-04-17	2	3	1	\N	3	\N
356	2026-04-17	3	3	1	\N	2	\N
357	2026-04-18	1	1	1	\N	3	\N
358	2026-04-18	1	3	1	\N	4	\N
359	2026-04-18	2	3	1	\N	3	\N
360	2026-04-18	3	3	1	\N	2	\N
361	2026-04-19	1	1	1	\N	3	\N
362	2026-04-19	1	3	1	\N	4	\N
363	2026-04-19	2	3	1	\N	3	\N
364	2026-04-19	3	3	1	\N	2	\N
365	2026-04-13	1	2	1	\N	3	\N
366	2026-04-14	1	2	1	\N	3	\N
367	2026-04-15	1	2	1	\N	3	\N
368	2026-04-16	1	2	1	\N	3	\N
369	2026-04-17	1	2	1	\N	3	\N
370	2026-04-18	1	2	1	\N	3	\N
371	2026-04-19	1	2	1	\N	3	\N
372	2026-04-13	1	4	1	\N	3	\N
373	2026-04-14	1	4	1	\N	3	\N
374	2026-04-15	1	4	1	\N	3	\N
375	2026-04-16	1	4	1	\N	3	\N
376	2026-04-17	1	4	1	\N	3	\N
377	2026-04-18	1	4	1	\N	3	\N
378	2026-04-19	1	4	1	\N	3	\N
379	2026-04-13	2	1	1	\N	3	\N
380	2026-04-14	2	1	1	\N	3	\N
381	2026-04-15	2	1	1	\N	3	\N
382	2026-04-16	2	1	1	\N	3	\N
383	2026-04-17	2	1	1	\N	3	\N
384	2026-04-18	2	1	1	\N	3	\N
385	2026-04-19	2	1	1	\N	3	\N
386	2026-04-13	2	4	1	\N	3	\N
387	2026-04-14	2	4	1	\N	3	\N
388	2026-04-15	2	4	1	\N	3	\N
389	2026-04-16	2	4	1	\N	3	\N
390	2026-04-17	2	4	1	\N	3	\N
391	2026-04-18	2	4	1	\N	3	\N
392	2026-04-19	2	4	1	\N	3	\N
\.


--
-- Data for Name: trong_so_uu_tien; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.trong_so_uu_tien (id, khoa, gia_tri) FROM stdin;
1	uu_tien_ca_ua_thich	4
2	phat_ca_tranh	6
3	cong_bang_chich_ngoai	5
4	cong_bang_cuoi_tuan	4
5	khong_di_chich_ngoai	6
6	uu_tien_ca_quan_trong	3
7	han_che_ca_muon_sang	2
8	bat_buoc_chich_ngoai	1
\.


--
-- Data for Name: vai_tro; Type: TABLE DATA; Schema: public; Owner: lich_user
--

COPY public.vai_tro (id, ten_vai_tro) FROM stdin;
1	Bác sỹ
2	KTV
3	Lễ tân
\.


--
-- Name: ca_lam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lich_user
--

SELECT pg_catalog.setval('public.ca_lam_id_seq', 5, true);


--
-- Name: chi_nhanh_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lich_user
--

SELECT pg_catalog.setval('public.chi_nhanh_id_seq', 3, true);


--
-- Name: lich_chi_tiet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lich_user
--

SELECT pg_catalog.setval('public.lich_chi_tiet_id_seq', 3850, true);


--
-- Name: lich_tuan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lich_user
--

SELECT pg_catalog.setval('public.lich_tuan_id_seq', 50, true);


--
-- Name: mapping_nhom_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lich_user
--

SELECT pg_catalog.setval('public.mapping_nhom_id_seq', 9, true);


--
-- Name: ngay_nghi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lich_user
--

SELECT pg_catalog.setval('public.ngay_nghi_id_seq', 46, true);


--
-- Name: nhan_vien_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lich_user
--

SELECT pg_catalog.setval('public.nhan_vien_id_seq', 11, true);


--
-- Name: nhan_vien_trong_so_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lich_user
--

SELECT pg_catalog.setval('public.nhan_vien_trong_so_id_seq', 7, true);


--
-- Name: nhom_hien_thi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lich_user
--

SELECT pg_catalog.setval('public.nhom_hien_thi_id_seq', 7, true);


--
-- Name: nhu_cau_ca_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lich_user
--

SELECT pg_catalog.setval('public.nhu_cau_ca_id_seq', 392, true);


--
-- Name: trong_so_uu_tien_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lich_user
--

SELECT pg_catalog.setval('public.trong_so_uu_tien_id_seq', 8, true);


--
-- Name: vai_tro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lich_user
--

SELECT pg_catalog.setval('public.vai_tro_id_seq', 3, true);


--
-- Name: ca_lam ca_lam_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.ca_lam
    ADD CONSTRAINT ca_lam_pkey PRIMARY KEY (id);


--
-- Name: ca_lam ca_lam_ten_ca_key; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.ca_lam
    ADD CONSTRAINT ca_lam_ten_ca_key UNIQUE (ten_ca);


--
-- Name: chi_nhanh chi_nhanh_ma_chi_nhanh_key; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.chi_nhanh
    ADD CONSTRAINT chi_nhanh_ma_chi_nhanh_key UNIQUE (ma_chi_nhanh);


--
-- Name: chi_nhanh chi_nhanh_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.chi_nhanh
    ADD CONSTRAINT chi_nhanh_pkey PRIMARY KEY (id);


--
-- Name: lich_chi_tiet lich_chi_tiet_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.lich_chi_tiet
    ADD CONSTRAINT lich_chi_tiet_pkey PRIMARY KEY (id);


--
-- Name: lich_tuan lich_tuan_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.lich_tuan
    ADD CONSTRAINT lich_tuan_pkey PRIMARY KEY (id);


--
-- Name: mapping_nhom mapping_nhom_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.mapping_nhom
    ADD CONSTRAINT mapping_nhom_pkey PRIMARY KEY (id);


--
-- Name: ngay_nghi ngay_nghi_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.ngay_nghi
    ADD CONSTRAINT ngay_nghi_pkey PRIMARY KEY (id);


--
-- Name: nhan_vien_ca_tranh nhan_vien_ca_tranh_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_ca_tranh
    ADD CONSTRAINT nhan_vien_ca_tranh_pkey PRIMARY KEY (nhan_vien_id, ca_id);


--
-- Name: nhan_vien_ca_ua_thich nhan_vien_ca_ua_thich_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_ca_ua_thich
    ADD CONSTRAINT nhan_vien_ca_ua_thich_pkey PRIMARY KEY (nhan_vien_id, ca_id);


--
-- Name: nhan_vien_chi_nhanh nhan_vien_chi_nhanh_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_chi_nhanh
    ADD CONSTRAINT nhan_vien_chi_nhanh_pkey PRIMARY KEY (nhan_vien_id, chi_nhanh_id);


--
-- Name: nhan_vien nhan_vien_ma_nv_key; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien
    ADD CONSTRAINT nhan_vien_ma_nv_key UNIQUE (ma_nv);


--
-- Name: nhan_vien nhan_vien_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien
    ADD CONSTRAINT nhan_vien_pkey PRIMARY KEY (id);


--
-- Name: nhan_vien_trong_so nhan_vien_trong_so_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_trong_so
    ADD CONSTRAINT nhan_vien_trong_so_pkey PRIMARY KEY (id);


--
-- Name: nhan_vien_vai_tro nhan_vien_vai_tro_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_vai_tro
    ADD CONSTRAINT nhan_vien_vai_tro_pkey PRIMARY KEY (nhan_vien_id, vai_tro_id);


--
-- Name: nhom_hien_thi nhom_hien_thi_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhom_hien_thi
    ADD CONSTRAINT nhom_hien_thi_pkey PRIMARY KEY (id);


--
-- Name: nhom_hien_thi nhom_hien_thi_ten_nhom_key; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhom_hien_thi
    ADD CONSTRAINT nhom_hien_thi_ten_nhom_key UNIQUE (ten_nhom);


--
-- Name: nhu_cau_ca nhu_cau_ca_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhu_cau_ca
    ADD CONSTRAINT nhu_cau_ca_pkey PRIMARY KEY (id);


--
-- Name: trong_so_uu_tien trong_so_uu_tien_khoa_key; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.trong_so_uu_tien
    ADD CONSTRAINT trong_so_uu_tien_khoa_key UNIQUE (khoa);


--
-- Name: trong_so_uu_tien trong_so_uu_tien_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.trong_so_uu_tien
    ADD CONSTRAINT trong_so_uu_tien_pkey PRIMARY KEY (id);


--
-- Name: vai_tro vai_tro_pkey; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.vai_tro
    ADD CONSTRAINT vai_tro_pkey PRIMARY KEY (id);


--
-- Name: vai_tro vai_tro_ten_vai_tro_key; Type: CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.vai_tro
    ADD CONSTRAINT vai_tro_ten_vai_tro_key UNIQUE (ten_vai_tro);


--
-- Name: ix_ca_lam_id; Type: INDEX; Schema: public; Owner: lich_user
--

CREATE INDEX ix_ca_lam_id ON public.ca_lam USING btree (id);


--
-- Name: ix_chi_nhanh_id; Type: INDEX; Schema: public; Owner: lich_user
--

CREATE INDEX ix_chi_nhanh_id ON public.chi_nhanh USING btree (id);


--
-- Name: ix_lich_chi_tiet_id; Type: INDEX; Schema: public; Owner: lich_user
--

CREATE INDEX ix_lich_chi_tiet_id ON public.lich_chi_tiet USING btree (id);


--
-- Name: ix_lich_tuan_id; Type: INDEX; Schema: public; Owner: lich_user
--

CREATE INDEX ix_lich_tuan_id ON public.lich_tuan USING btree (id);


--
-- Name: ix_mapping_nhom_id; Type: INDEX; Schema: public; Owner: lich_user
--

CREATE INDEX ix_mapping_nhom_id ON public.mapping_nhom USING btree (id);


--
-- Name: ix_ngay_nghi_id; Type: INDEX; Schema: public; Owner: lich_user
--

CREATE INDEX ix_ngay_nghi_id ON public.ngay_nghi USING btree (id);


--
-- Name: ix_nhan_vien_id; Type: INDEX; Schema: public; Owner: lich_user
--

CREATE INDEX ix_nhan_vien_id ON public.nhan_vien USING btree (id);


--
-- Name: ix_nhan_vien_trong_so_id; Type: INDEX; Schema: public; Owner: lich_user
--

CREATE INDEX ix_nhan_vien_trong_so_id ON public.nhan_vien_trong_so USING btree (id);


--
-- Name: ix_nhom_hien_thi_id; Type: INDEX; Schema: public; Owner: lich_user
--

CREATE INDEX ix_nhom_hien_thi_id ON public.nhom_hien_thi USING btree (id);


--
-- Name: ix_nhu_cau_ca_id; Type: INDEX; Schema: public; Owner: lich_user
--

CREATE INDEX ix_nhu_cau_ca_id ON public.nhu_cau_ca USING btree (id);


--
-- Name: ix_trong_so_uu_tien_id; Type: INDEX; Schema: public; Owner: lich_user
--

CREATE INDEX ix_trong_so_uu_tien_id ON public.trong_so_uu_tien USING btree (id);


--
-- Name: ix_vai_tro_id; Type: INDEX; Schema: public; Owner: lich_user
--

CREATE INDEX ix_vai_tro_id ON public.vai_tro USING btree (id);


--
-- Name: lich_chi_tiet lich_chi_tiet_ca_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.lich_chi_tiet
    ADD CONSTRAINT lich_chi_tiet_ca_id_fkey FOREIGN KEY (ca_id) REFERENCES public.ca_lam(id) ON DELETE SET NULL;


--
-- Name: lich_chi_tiet lich_chi_tiet_chi_nhanh_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.lich_chi_tiet
    ADD CONSTRAINT lich_chi_tiet_chi_nhanh_id_fkey FOREIGN KEY (chi_nhanh_id) REFERENCES public.chi_nhanh(id) ON DELETE SET NULL;


--
-- Name: lich_chi_tiet lich_chi_tiet_lich_tuan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.lich_chi_tiet
    ADD CONSTRAINT lich_chi_tiet_lich_tuan_id_fkey FOREIGN KEY (lich_tuan_id) REFERENCES public.lich_tuan(id) ON DELETE CASCADE;


--
-- Name: lich_chi_tiet lich_chi_tiet_nhan_vien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.lich_chi_tiet
    ADD CONSTRAINT lich_chi_tiet_nhan_vien_id_fkey FOREIGN KEY (nhan_vien_id) REFERENCES public.nhan_vien(id) ON DELETE CASCADE;


--
-- Name: lich_chi_tiet lich_chi_tiet_nhom_hien_thi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.lich_chi_tiet
    ADD CONSTRAINT lich_chi_tiet_nhom_hien_thi_id_fkey FOREIGN KEY (nhom_hien_thi_id) REFERENCES public.nhom_hien_thi(id) ON DELETE SET NULL;


--
-- Name: mapping_nhom mapping_nhom_ca_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.mapping_nhom
    ADD CONSTRAINT mapping_nhom_ca_id_fkey FOREIGN KEY (ca_id) REFERENCES public.ca_lam(id) ON DELETE CASCADE;


--
-- Name: mapping_nhom mapping_nhom_chi_nhanh_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.mapping_nhom
    ADD CONSTRAINT mapping_nhom_chi_nhanh_id_fkey FOREIGN KEY (chi_nhanh_id) REFERENCES public.chi_nhanh(id) ON DELETE CASCADE;


--
-- Name: mapping_nhom mapping_nhom_nhom_hien_thi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.mapping_nhom
    ADD CONSTRAINT mapping_nhom_nhom_hien_thi_id_fkey FOREIGN KEY (nhom_hien_thi_id) REFERENCES public.nhom_hien_thi(id) ON DELETE CASCADE;


--
-- Name: ngay_nghi ngay_nghi_nhan_vien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.ngay_nghi
    ADD CONSTRAINT ngay_nghi_nhan_vien_id_fkey FOREIGN KEY (nhan_vien_id) REFERENCES public.nhan_vien(id) ON DELETE CASCADE;


--
-- Name: nhan_vien_ca_tranh nhan_vien_ca_tranh_ca_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_ca_tranh
    ADD CONSTRAINT nhan_vien_ca_tranh_ca_id_fkey FOREIGN KEY (ca_id) REFERENCES public.ca_lam(id) ON DELETE CASCADE;


--
-- Name: nhan_vien_ca_tranh nhan_vien_ca_tranh_nhan_vien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_ca_tranh
    ADD CONSTRAINT nhan_vien_ca_tranh_nhan_vien_id_fkey FOREIGN KEY (nhan_vien_id) REFERENCES public.nhan_vien(id) ON DELETE CASCADE;


--
-- Name: nhan_vien_ca_ua_thich nhan_vien_ca_ua_thich_ca_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_ca_ua_thich
    ADD CONSTRAINT nhan_vien_ca_ua_thich_ca_id_fkey FOREIGN KEY (ca_id) REFERENCES public.ca_lam(id) ON DELETE CASCADE;


--
-- Name: nhan_vien_ca_ua_thich nhan_vien_ca_ua_thich_nhan_vien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_ca_ua_thich
    ADD CONSTRAINT nhan_vien_ca_ua_thich_nhan_vien_id_fkey FOREIGN KEY (nhan_vien_id) REFERENCES public.nhan_vien(id) ON DELETE CASCADE;


--
-- Name: nhan_vien_chi_nhanh nhan_vien_chi_nhanh_chi_nhanh_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_chi_nhanh
    ADD CONSTRAINT nhan_vien_chi_nhanh_chi_nhanh_id_fkey FOREIGN KEY (chi_nhanh_id) REFERENCES public.chi_nhanh(id) ON DELETE CASCADE;


--
-- Name: nhan_vien_chi_nhanh nhan_vien_chi_nhanh_nhan_vien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_chi_nhanh
    ADD CONSTRAINT nhan_vien_chi_nhanh_nhan_vien_id_fkey FOREIGN KEY (nhan_vien_id) REFERENCES public.nhan_vien(id) ON DELETE CASCADE;


--
-- Name: nhan_vien_trong_so nhan_vien_trong_so_nhan_vien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_trong_so
    ADD CONSTRAINT nhan_vien_trong_so_nhan_vien_id_fkey FOREIGN KEY (nhan_vien_id) REFERENCES public.nhan_vien(id) ON DELETE CASCADE;


--
-- Name: nhan_vien_trong_so nhan_vien_trong_so_trong_so_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_trong_so
    ADD CONSTRAINT nhan_vien_trong_so_trong_so_id_fkey FOREIGN KEY (trong_so_id) REFERENCES public.trong_so_uu_tien(id) ON DELETE CASCADE;


--
-- Name: nhan_vien_vai_tro nhan_vien_vai_tro_nhan_vien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_vai_tro
    ADD CONSTRAINT nhan_vien_vai_tro_nhan_vien_id_fkey FOREIGN KEY (nhan_vien_id) REFERENCES public.nhan_vien(id) ON DELETE CASCADE;


--
-- Name: nhan_vien_vai_tro nhan_vien_vai_tro_vai_tro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhan_vien_vai_tro
    ADD CONSTRAINT nhan_vien_vai_tro_vai_tro_id_fkey FOREIGN KEY (vai_tro_id) REFERENCES public.vai_tro(id) ON DELETE CASCADE;


--
-- Name: nhu_cau_ca nhu_cau_ca_ca_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhu_cau_ca
    ADD CONSTRAINT nhu_cau_ca_ca_id_fkey FOREIGN KEY (ca_id) REFERENCES public.ca_lam(id) ON DELETE CASCADE;


--
-- Name: nhu_cau_ca nhu_cau_ca_chi_nhanh_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhu_cau_ca
    ADD CONSTRAINT nhu_cau_ca_chi_nhanh_id_fkey FOREIGN KEY (chi_nhanh_id) REFERENCES public.chi_nhanh(id) ON DELETE SET NULL;


--
-- Name: nhu_cau_ca nhu_cau_ca_vai_tro_yeu_cau_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lich_user
--

ALTER TABLE ONLY public.nhu_cau_ca
    ADD CONSTRAINT nhu_cau_ca_vai_tro_yeu_cau_id_fkey FOREIGN KEY (vai_tro_yeu_cau_id) REFERENCES public.vai_tro(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict XRjrqOdVhjfXnmtfulEf4GuzEYf7gptc8gc8HWPby0vE2vBYuyZhiCyPV2r08VU

